package org.array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

public class Arraysum {
	public static void main(String[] args) {
		 ArrayList<Integer> list = new ArrayList<>();
	        list.add(10);
	        list.add(20);
	        list.add(30);
	        list.add(90);
	        list.add(10);
	        list.add(10);
	        list.add(40);
	        list.add(50);

	       
	        System.out.println("ArrayList: " + list);
	        
	        
	        Set<Integer>   s = new TreeSet<>();
	        
	        s.addAll(list);
	        
	        System.out.println("the final array answer is:" +s);

	     
	        int length = list.size();
	        System.out.println("Length of the ArrayList: " + length);
}
	}

     
