package org.java;

public class Company {
	private void companyName() {
		// TODO Auto-generated method stub
		System.out.println("tcs");
		}
		private void companyId() {
		// TODO Auto-generated method stub
		System.out.println("123");
		}
		private void companyAddress() {
		// TODO Auto-generated method stub
		System.out.println("chennai");
		}
		public static void main(String[] args) {
		Company c = new Company();
		c.companyName();
		c.companyId();
		c.companyAddress();
		}

}
