package org.java;

public class Company {
	public void companyName() {
		// TODO Auto-generated method stub
		System.out.println("company name is CTS");
		}


}
