package org.java;

public class Client {
	public void clientName() {
		// TODO Auto-generated method stub
		System.out.println("client is msajce");
		}

}
