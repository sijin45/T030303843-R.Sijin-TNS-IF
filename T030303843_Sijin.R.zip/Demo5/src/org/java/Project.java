package org.java;

public class Project {
	public void projectName() {
		// TODO Auto-generated method stub
		System.out.println("project is WEB Auto");
		}


}
