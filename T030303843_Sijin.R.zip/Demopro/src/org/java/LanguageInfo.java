package org.java;

public class LanguageInfo {
	public void tamil() {
		// TODO Auto-generated method stub
		System.out.println("tamil");
		}
		public void english() {
		// TODO Auto-generated method stub
		System.out.println("english");
		}

}
