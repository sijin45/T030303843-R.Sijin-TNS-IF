package org.java;

public class Student {public void stName() {
	// TODO Auto-generated method stub
	System.out.println("Richardson");
	}
	public void stDep() {
	// TODO Auto-generated method stub
	System.out.println("cse");
	}
	public void stId() {
	// TODO Auto-generated method stub
	System.out.println("311821104046");
	}
	public void stHostelName() {
	// TODO Auto-generated method stub
	System.out.println("ram Ug");
	}


}
