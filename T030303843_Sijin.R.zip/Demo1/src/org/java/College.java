package org.java;

public class College {
	private void collegeName() {
		// TODO Auto-generated method stub
		System.out.println("msajce");
		}
		private void collegeCode() {
		// TODO Auto-generated method stub
		System.out.println("3118");
		}
		private void collegeRank() {
		// TODO Auto-generated method stub
		System.out.println("rank 5");
		}
		public static void main(String[] args) {
		College c = new College();
		Student s = new Student();
		c.collegeName();
		c.collegeCode();
		c.collegeRank();
		s.stName();
		s.stDep();
		s.stId();
		s.stHostelName();
		}


}
