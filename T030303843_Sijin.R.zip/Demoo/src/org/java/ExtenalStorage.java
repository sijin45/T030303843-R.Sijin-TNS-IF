package org.java;

public class ExtenalStorage {
	public void sizeExt() {
		// TODO Auto-generated method stub
		System.out.println("external storage is 512 gb");
		}


}
