package org.java;

public class Wifi {

}
