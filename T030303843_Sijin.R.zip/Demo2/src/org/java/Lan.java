package org.java;

public class Lan {

}
