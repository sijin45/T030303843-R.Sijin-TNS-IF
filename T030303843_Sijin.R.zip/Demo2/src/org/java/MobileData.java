package org.java;

public class MobileData {

}
